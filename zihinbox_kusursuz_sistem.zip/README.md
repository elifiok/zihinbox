# ZihinBox
Kapsamlı ve detaylı öğrenci platformu.